const {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionsBitField,
  EmbedBuilder
} = require("discord.js");
const fs = require("fs");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

/* ===== ARQUIVO ===== */
const FILE = "./config.json";

let config = {
  categorias: {
    suporte: null,
    denuncia: null,
    compra: null
  },
  staffRole: null,
  embed: {
    cor: "#FF0000",
    titulo: "🎫 Central de Atendimento",
    descricao: "Selecione uma opção abaixo",
    imagem: null
  }
};

if (fs.existsSync(FILE)) {
  config = JSON.parse(fs.readFileSync(FILE));
}

function salvar() {
  fs.writeFileSync(FILE, JSON.stringify(config, null, 2));
}

/* ===== READY ===== */
client.once("ready", () => {
  console.log(`✅ Bot online: ${client.user.tag}`);
});

/* ===== COMANDO ===== */
client.on("messageCreate", async (msg) => {
  if (!msg.guild || msg.author.bot) return;

  if (msg.content === "!painelticket") {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("config").setLabel("Configurar").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("embed").setLabel("Embed").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("criar").setLabel("Criar").setStyle(ButtonStyle.Success)
    );

    msg.channel.send({ content: "🎛️ **Painel de Ticket**", components: [row] });
  }
});

/* ===== INTERAÇÕES ===== */
client.on("interactionCreate", async (interaction) => {

  /* ===== BOTÕES ===== */
  if (interaction.isButton()) {

    /* CONFIG */
    if (interaction.customId === "config") {
      await interaction.reply({
        content:
          "Envie **NESTA ORDEM**:\n" +
          "`ID CATEGORIA SUPORTE`\n" +
          "`ID CATEGORIA DENÚNCIA`\n" +
          "`ID CATEGORIA COMPRA`\n" +
          "`ID CARGO STAFF`",
        ephemeral: true
      });

      const coletor = interaction.channel.createMessageCollector({
        filter: m => m.author.id === interaction.user.id,
        max: 4,
        time: 120000
      });

      let etapa = 0;

      coletor.on("collect", m => {
        if (etapa === 0) config.categorias.suporte = m.content;
        if (etapa === 1) config.categorias.denuncia = m.content;
        if (etapa === 2) config.categorias.compra = m.content;
        if (etapa === 3) config.staffRole = m.content;
        etapa++;
        m.delete().catch(() => {});
      });

      coletor.on("end", () => {
        salvar();
        interaction.followUp({ content: "✅ Configuração salva!", ephemeral: true });
      });
    }

    /* EMBED */
    if (interaction.customId === "embed") {
      await interaction.reply({
        content:
          "Envie **NESTA ORDEM**:\n" +
          "`COR HEX (#FF0000)`\n" +
          "`TÍTULO`\n" +
          "`DESCRIÇÃO`\n" +
          "`LINK DA IMAGEM (ou digite NAO)`",
        ephemeral: true
      });

      const coletor = interaction.channel.createMessageCollector({
        filter: m => m.author.id === interaction.user.id,
        max: 4,
        time: 120000
      });

      let etapa = 0;

      coletor.on("collect", m => {
        if (etapa === 0) config.embed.cor = m.content;
        if (etapa === 1) config.embed.titulo = m.content;
        if (etapa === 2) config.embed.descricao = m.content;
        if (etapa === 3) config.embed.imagem = m.content.toLowerCase() === "nao" ? null : m.content;
        etapa++;
        m.delete().catch(() => {});
      });

      coletor.on("end", () => {
        salvar();
        interaction.followUp({ content: "✅ Embed salvo!", ephemeral: true });
      });
    }

    /* CRIAR PAINEL */
    if (interaction.customId === "criar") {
      const embed = new EmbedBuilder()
        .setColor(config.embed.cor)
        .setTitle(config.embed.titulo)
        .setDescription(config.embed.descricao);

      if (config.embed.imagem) embed.setImage(config.embed.imagem);

      const menu = new StringSelectMenuBuilder()
        .setCustomId("menu_ticket")
        .setPlaceholder("Escolha uma opção")
        .addOptions(
          { label: "Suporte", value: "suporte", emoji: "🛠️" },
          { label: "Denúncia", value: "denuncia", emoji: "🚨" },
          { label: "Compra", value: "compra", emoji: "🛒" }
        );

      interaction.reply({
        embeds: [embed],
        components: [new ActionRowBuilder().addComponents(menu)]
      });
    }

    /* FECHAR TICKET */
    if (interaction.customId === "fechar_ticket") {
      if (!interaction.member.roles.cache.has(config.staffRole)) {
        return interaction.reply({ content: "❌ Apenas STAFF pode fechar.", ephemeral: true });
      }

      await interaction.reply("🔒 Ticket será fechado em 5 segundos...");
      setTimeout(() => interaction.channel.delete(), 5000);
    }
  }

  /* ===== MENU ===== */
  if (interaction.isStringSelectMenu() && interaction.customId === "menu_ticket") {
    await interaction.deferReply({ ephemeral: true });

    const tipo = interaction.values[0];
    const categoria = interaction.guild.channels.cache.get(config.categorias[tipo]);
    if (!categoria) return interaction.editReply("❌ Categoria inválida.");

    const nome = `ticket-${tipo}-${interaction.user.username}`.toLowerCase();

    const canal = await interaction.guild.channels.create({
      name: nome,
      type: ChannelType.GuildText,
      parent: categoria,
      permissionOverwrites: [
        { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
        { id: config.staffRole, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
      ]
    });

    const fecharBtn = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("fechar_ticket")
        .setLabel("🔒 Fechar Ticket")
        .setStyle(ButtonStyle.Danger)
    );

    canal.send({
      content: `🎫 Ticket de ${interaction.user}`,
      components: [fecharBtn]
    });

    interaction.editReply(`✅ Ticket criado: ${canal}`);
  }
});

/* ===== LOGIN ===== */
client.login("MTQ3MDMwNTM3MzM2OTAxMjIzNQ.GVEEa_._YQAR9q9xinon3dWvoNj6TJ-AuyeOv9CNLYFCo");
